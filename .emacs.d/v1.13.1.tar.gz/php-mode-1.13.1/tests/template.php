<?php

/**
 * GitHub Issue:    https://github.com/ejmr/php-mode/issues/NNN
 *
 * ---------------------------------------------------------------------- 
 * Add the correct issue number to the URL above, replacing the 'NNN',
 * and then replace this with a description of the test and its
 * purpose, using the existing tests as examples.
 * ----------------------------------------------------------------------
 * 
 */
